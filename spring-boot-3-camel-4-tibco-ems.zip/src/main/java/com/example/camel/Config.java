package com.example.camel;

import jakarta.jms.ConnectionFactory;
import org.apache.camel.component.jms.JmsComponent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.tibco.tibjms.TibjmsConnectionFactory;

@Configuration
public class Config {

    @Bean
    public ConnectionFactory connectionFactory(
            @Value("${tibco.url}") String url,
            @Value("${tibco.username}") String username,
            @Value("${tibco.password}") String password) {

        TibjmsConnectionFactory tibjmsConnectionFactory = new TibjmsConnectionFactory();
        tibjmsConnectionFactory.setServerUrl(url);
        tibjmsConnectionFactory.setUserName(username);
        tibjmsConnectionFactory.setUserPassword(password);

        return new JakartaTibcoConnectionFactory(tibjmsConnectionFactory);
    }

    @Bean
    public JmsComponent jmsComponent(ConnectionFactory connectionFactory) {
        return JmsComponent.jmsComponentAutoAcknowledge(connectionFactory);
    }
}