package com.example.camel;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class TibcoRoute extends RouteBuilder {

    @Override
    public void configure() {
        from("jms:queue:TEST.QUEUE")
            .log("Received message from Tibco EMS: ${body}");
    }
}