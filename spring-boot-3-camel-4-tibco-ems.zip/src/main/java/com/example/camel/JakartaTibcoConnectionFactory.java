package com.example.camel;

import jakarta.jms.ConnectionFactory;
import com.tibco.tibjms.TibjmsConnectionFactory;

public class JakartaTibcoConnectionFactory implements ConnectionFactory {

    private final TibjmsConnectionFactory delegate;

    public JakartaTibcoConnectionFactory(TibjmsConnectionFactory delegate) {
        this.delegate = delegate;
    }

    @Override
    public jakarta.jms.Connection createConnection() throws jakarta.jms.JMSException {
        return delegate.createConnection();
    }

    @Override
    public jakarta.jms.Connection createConnection(String username, String password) throws jakarta.jms.JMSException {
        return delegate.createConnection(username, password);
    }
}